// The on-screen panel. Receives table events from hook.js, keeps reads on every
// player, and asks the solver (background.js) for advice when it's your turn.
(function () {
  'use strict';
  if (window.__patioSolverOverlay) return;
  window.__patioSolverOverlay = true;

  const TEST = globalThis.__PS_TEST || null; // used only for in-page testing
  // chrome.storage.local, with failures reported (a full or broken store used to drop saves
  // without a word). TEST.area replaces it in tests.
  const settle = (res) => () => {
    const err = chrome.runtime.lastError;
    res(err ? { ok: false, error: err.message || String(err) } : { ok: true });
  };
  const call = (fn) => new Promise((res) => {
    try { fn(res); } catch (e) { res({ ok: false, error: (e && e.message) || String(e) }); }
  });
  // Reads answer null when they fail, so a failed read is never taken for empty storage.
  const read = (fn) => new Promise((res) => {
    try { fn((v) => res(chrome.runtime.lastError ? null : v)); } catch (e) { res(null); }
  });
  const local = TEST ? TEST.area : {
    get: (keys) => read((cb) => chrome.storage.local.get(keys, (v) => cb(v || {}))),
    set: (items) => call((res) => chrome.storage.local.set(items, settle(res))),
    remove: (keys) => call((res) => chrome.storage.local.remove(keys, settle(res))),
    keys: chrome.storage.local.getKeys ? () => read((cb) => chrome.storage.local.getKeys((k) => cb(k || []))) : null,
  };
  let saveError = null; // shown on the panel until a save works again
  const noteSaved = (r) => {
    const err = r && !r.ok ? r.error || 'unknown error' : null;
    if (err !== saveError) { saveError = err; render(); }
    return r;
  };
  const store = {
    get: (k) => local.get(k).then((v) => (v || {})[k]),
    set: (k, v) => local.set({ [k]: v }).then(noteSaved),
  };
  const analyze = TEST ? TEST.analyze : (input) => new Promise((res) => {
    try {
      chrome.runtime.sendMessage({ type: 'analyze', input }, (r) => {
        if (chrome.runtime.lastError) res({ ok: false, error: chrome.runtime.lastError.message });
        else res(r || { ok: false, error: 'No answer from the solver.' });
      });
    } catch (e) {
      res({ ok: false, error: 'Extension was reloaded. Refresh this page.' });
    }
  });

  const DB_KEY = 'patioSolverDb';
  const UI_KEY = 'patioSolverUi';
  // Reads under DB_KEY, each hand of the log under its own key (handlog.js).
  const handLog = PatioHandLog.create(local, DB_KEY);
  // A copy of the reads in the site's own storage, which survives removing the extension (backup.js).
  const backup = PatioBackup.create(TEST && TEST.backupArea ? TEST.backupArea : PatioBackup.idbArea('patio-solver', 'kv'), TEST && TEST.backupOpts);
  const saveDb = () => {
    if (!tracker) return null;
    backup.save(tracker.db).catch(() => null);
    return handLog.save(tracker.db).then(noteSaved);
  };

  let tracker = null;
  let ui = { tableStyle: 'typical', x: null, y: 80, collapsed: false, showOptions: true, showLinks: false, showLog: false };
  let status = 'Connecting to the table…';
  let importNote = '', importing = false, restored = false;
  let linkNote = ''; // the last link answer (or why a link was refused)
  let advice = null; // { result, ctx, forHandStreet, stale }
  let thinking = false;
  let blocked = false;
  let hookProblem = null; // hook.js watchdog: 'nosocket' | 'silent' | null
  let reqId = 0;

  // Bets and raises well under the advised size (the tracker's sizeRatio: chips hero put in over
  // the advised chips). In the simulator, betting 0.4x the advice with 4 in 10 strong hands, as on
  // 1 Nov, cost about 87 bb/100. Shown under the advice it answered, and counted for the session.
  const SMALL_SIZE = 0.6;
  const sizing = { n: 0, small: 0, note: null };
  const sizeSeen = new WeakSet();
  function checkSize() {
    const h = tracker && tracker.hand;
    if (!h || !h.advice) return;
    for (const a of h.advice) {
      if (a.sizeRatio == null || sizeSeen.has(a)) continue;
      sizeSeen.add(a);
      sizing.n++;
      if (a.sizeRatio < SMALL_SIZE && a.amount > 0) {
        sizing.small++;
        sizing.note = `Smaller than advised: you put in ${money(a.amount * a.sizeRatio)} of the advised ${money(a.amount)}.`;
      } else sizing.note = null;
    }
  }

  // ---------- formatting ----------
  const money = (x) => '$' + Math.round(x).toLocaleString('en-US');
  const pct = (x) => (x == null ? '–' : Math.round(x * 100) + '%');
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const SUITSYM = { c: '♣', d: '♦', h: '♥', s: '♠' };
  const cardHtml = (c) => `<span class="cd ${c[1] === 'h' || c[1] === 'd' ? 'red' : ''}">${c[0] === 'T' ? '10' : c[0]}${SUITSYM[c[1]]}</span>`;

  // Raises read the way the site's raise box takes them: the chips on top of the call ("raise by"),
  // with the street total after it. On Poker Patio, raise 3 facing a bet of 2 makes the bet 5.
  function actionParts(sc, heroStageBet, toCall) {
    if (!sc) return { main: '' };
    if (sc.kind === 'fold') return { main: 'Fold' };
    if (sc.kind === 'check') return { main: 'Check' };
    if (sc.kind === 'call') return { main: 'Call ' + money(sc.amount) };
    if (sc.kind === 'allin') return { main: sc.amount <= toCall + 1e-9 ? 'Call all-in ' + money(sc.amount) : 'All-in ' + money(heroStageBet + sc.amount) };
    if (sc.kind === 'bet' && heroStageBet <= 0) return { main: 'Bet ' + money(sc.amount) };
    const to = Math.round(heroStageBet + sc.amount);
    return { main: 'Raise by ' + money(to - Math.round(heroStageBet + toCall)), to: money(to) };
  }
  function actionText(sc, heroStageBet, toCall) {
    const a = actionParts(sc, heroStageBet, toCall);
    return a.to ? a.main + ' (to ' + a.to + ')' : a.main;
  }
  function actionHtml(sc, heroStageBet, toCall) {
    const a = actionParts(sc, heroStageBet, toCall);
    return esc(a.main) + (a.to ? ' <span class="to">to ' + esc(a.to) + '</span>' : '');
  }
  // A row of "All options": the action, then the raise's total, size and play share, muted.
  function optionHtml(sc, heroStageBet, toCall) {
    const a = actionParts(sc, heroStageBet, toCall);
    const notes = [a.to && 'to ' + a.to, sc.sizeLabel && sc.sizeLabel !== 'raise' && sc.sizeLabel].filter(Boolean);
    if (sc.freq != null) notes.push((notes.length ? '' : '· ') + 'play ' + pct(sc.freq));
    return esc(a.main) + (notes.length ? ' <span class="muted">' + esc(notes.join(' · ')) + '</span>' : '');
  }
  function tone(sc) {
    if (!sc) return '';
    if (sc.kind === 'fold') return 'fold';
    if (sc.kind === 'check' || sc.kind === 'call') return 'passive';
    return 'aggr';
  }

  // ---------- DOM ----------
  const host = document.createElement('div');
  host.id = 'patio-solver-host';
  host.style.cssText = 'position:fixed;z-index:2147483646;top:0;left:0;width:0;height:0;';
  const root = host.attachShadow({ mode: 'open' });
  root.innerHTML = `
  <style>
    :host { all: initial; }
    .panel { position: fixed; width: 300px; max-height: calc(100vh - 20px); overflow: auto;
      background: rgba(18,22,20,.94); color: #eef2ef; border: 1px solid rgba(255,255,255,.14);
      border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,.45);
      font: 13px/1.4 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
    .hd { display: flex; align-items: center; gap: 8px; padding: 8px 10px; cursor: move; user-select: none;
      border-bottom: 1px solid rgba(255,255,255,.08); }
    .hd b { font-size: 13px; letter-spacing: .02em; }
    .dot { width: 8px; height: 8px; border-radius: 50%; background: #777; flex: none; }
    .dot.live { background: #3fcf6e; } .dot.turn { background: #ffcc33; box-shadow: 0 0 8px #ffcc33; } .dot.bad { background: #ff6b6b; }
    .hd .sp { flex: 1; }
    .btn { background: rgba(255,255,255,.08); color: inherit; border: 0; border-radius: 6px; padding: 3px 8px;
      font: inherit; font-size: 12px; cursor: pointer; }
    .btn:hover { background: rgba(255,255,255,.16); }
    .bd { padding: 10px; display: flex; flex-direction: column; gap: 10px; }
    .status { color: #aab3ad; font-size: 12px; }
    .rec { border-radius: 10px; padding: 10px 12px; background: rgba(255,255,255,.06); }
    .rec .act { font-size: 22px; font-weight: 700; line-height: 1.15; }
    .rec .act .to { font-size: 13px; font-weight: 500; color: #95a09a; }
    .rec.aggr .act { color: #4be08a; } .rec.passive .act { color: #6cb8ff; } .rec.fold .act { color: #ff7a7a; }
    .rec .sub { color: #c4ccc6; font-size: 12px; margin-top: 3px; }
    .rec.stale { opacity: .45; }
    .badge { display: inline-block; font-size: 11px; padding: 1px 6px; border-radius: 99px; background: rgba(255,204,51,.18); color: #ffd866; margin-left: 6px; vertical-align: middle; }
    .hand { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
    .cd { display: inline-block; background: #f4f4f0; color: #111; border-radius: 4px; padding: 0 4px; font-weight: 700; font-size: 12px; }
    .cd.red { color: #c81e1e; }
    .muted { color: #95a09a; font-size: 12px; }
    .kv { display: grid; grid-template-columns: 1fr auto; gap: 2px 10px; font-size: 12px; }
    .kv span:nth-child(even) { text-align: right; font-variant-numeric: tabular-nums; }
    table { width: 100%; border-collapse: collapse; font-size: 12px; }
    td { padding: 2px 0; font-variant-numeric: tabular-nums; }
    td:last-child { text-align: right; }
    tr.best td { color: #fff; font-weight: 700; }
    .neg { color: #ff9a9a; } .pos { color: #8ff0b4; }
    .sec { font-size: 11px; text-transform: uppercase; letter-spacing: .06em; color: #8c968f; margin-bottom: 4px; }
    .opp { padding: 6px 0; border-top: 1px solid rgba(255,255,255,.06); }
    .opp:first-of-type { border-top: 0; }
    .opp .nm { font-weight: 600; }
    .opp .ty { font-size: 11px; padding: 1px 6px; border-radius: 99px; background: rgba(255,255,255,.1); margin-left: 4px; }
    .opp .tip { color: #aab3ad; font-size: 11.5px; margin-top: 2px; }
    .ft { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; padding: 8px 10px; border-top: 1px solid rgba(255,255,255,.08); }
    select { background: rgba(255,255,255,.08); color: inherit; border: 0; border-radius: 6px; padding: 3px 4px; font: inherit; font-size: 12px; }
    select option { color: #111; }
    .ask { border-radius: 10px; padding: 8px 10px; background: rgba(255,204,51,.12); border: 1px solid rgba(255,204,51,.35); font-size: 12px; }
    .ask .row { display: flex; gap: 6px; margin-top: 6px; flex-wrap: wrap; }
    .lk { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; padding: 4px 0; border-top: 1px solid rgba(255,255,255,.06); font-size: 12px; }
    .lk:first-of-type { border-top: 0; }
    .lk select { max-width: 180px; }
    .spin { display: inline-block; width: 10px; height: 10px; border: 2px solid rgba(255,255,255,.25); border-top-color: #fff; border-radius: 50%; animation: s .8s linear infinite; vertical-align: -1px; margin-right: 6px; }
    @keyframes s { to { transform: rotate(360deg); } }
  </style>
  <div class="panel">
    <div class="hd"><span class="dot"></span><b>Patio Solver</b><span class="sp"></span>
      <button class="btn" data-a="collapse">–</button></div>
    <div class="bd"></div>
    <div class="ft">
      <span class="muted">Table</span>
      <select data-a="style"><option value="tight">Tight</option><option value="typical">Typical</option><option value="loose">Loose</option></select>
      <span class="sp" style="flex:1"></span>
      <button class="btn" data-a="log" title="Download the hands since your last export, one session, or every stored hand">Hand log</button>
      <button class="btn" data-a="links" title="Join the reads of a friend who came back on a new account, or split them again">Link reads</button>
      <button class="btn" data-a="import" title="Load hand-log exports (from an older install) and rebuild the reads from every stored hand">Import</button>
      <button class="btn" data-a="reset">Reset reads</button>
      <input type="file" accept=".json,application/json" multiple style="display:none">
    </div>
  </div>`;
  const panel = root.querySelector('.panel');
  const body = root.querySelector('.bd');
  const dot = root.querySelector('.dot');
  const foot = root.querySelector('.ft');
  const styleSel = root.querySelector('select');
  const fileIn = root.querySelector('input[type=file]');

  function place() {
    const x = ui.x == null ? window.innerWidth - 316 : Math.min(Math.max(0, ui.x), window.innerWidth - 120);
    const y = Math.min(Math.max(0, ui.y), window.innerHeight - 40);
    panel.style.left = x + 'px';
    panel.style.top = y + 'px';
  }

  // Drag by the header.
  (function drag() {
    const hd = root.querySelector('.hd');
    let sx, sy, ox, oy, on = false;
    hd.addEventListener('pointerdown', (e) => {
      if (e.target.closest('button')) return;
      on = true; sx = e.clientX; sy = e.clientY;
      const r = panel.getBoundingClientRect(); ox = r.left; oy = r.top;
      hd.setPointerCapture(e.pointerId);
    });
    hd.addEventListener('pointermove', (e) => {
      if (!on) return;
      ui.x = ox + e.clientX - sx; ui.y = oy + e.clientY - sy; place();
    });
    hd.addEventListener('pointerup', () => { if (on) { on = false; store.set(UI_KEY, ui); } });
  })();

  root.addEventListener('click', (e) => {
    const a = e.target.closest('[data-a]');
    if (!a) return;
    const what = a.getAttribute('data-a');
    if (what === 'collapse') {
      ui.collapsed = !ui.collapsed; store.set(UI_KEY, ui); render();
    } else if (what === 'log') {
      if (!tracker) return;
      ui.showLog = !ui.showLog; logNote = ''; store.set(UI_KEY, ui);
      if (ui.showLog) { logView = null; refreshLog(); } else render();
    } else if (what === 'logNew' || what === 'logAll' || what === 'logSession') {
      exportLog(what, +a.getAttribute('data-from'), +a.getAttribute('data-to'));
    } else if (what === 'import') {
      if (!tracker || importing) return;
      fileIn.value = '';
      fileIn.click();
    } else if (what === 'reset') {
      if (!tracker) return;
      if (a.dataset.confirm !== '1') { a.dataset.confirm = '1'; a.textContent = 'Sure? Click again'; setTimeout(() => { a.dataset.confirm = ''; a.textContent = 'Reset reads'; }, 3000); return; }
      // The reads start over; the hand log stays.
      tracker.db = { players: {}, history: tracker.db.history || [] };
      tracker.linkAsks = null;
      tracker.learnSeats(tracker.db.history);
      backup.reset();
      saveDb();
      a.dataset.confirm = ''; a.textContent = 'Reset reads';
      render();
    } else if (what === 'toggleOpts') {
      ui.showOptions = !ui.showOptions; store.set(UI_KEY, ui); render();
    } else if (what === 'links') {
      ui.showLinks = !ui.showLinks; linkNote = ''; store.set(UI_KEY, ui); render();
    } else if (what === 'linkYes' || what === 'linkNo' || what === 'unlink') {
      if (!tracker) return;
      const id = a.getAttribute('data-id'), to = a.getAttribute('data-to');
      if (what === 'linkYes') {
        const r = tracker.link(id, to);
        linkNote = r.ok ? `Reads joined: ${r.info.names.join(' / ')}, ${handsTxt(r.info.hands)}.` : r.error;
      } else if (what === 'linkNo') {
        tracker.refuseLink(id, to);
        linkNote = 'Kept apart. You won\'t be asked about these two again.';
      } else {
        tracker.unlink(id);
        linkNote = `Split: ${tracker.namesOf(id)[0] || id} reads on their own again.`;
      }
      afterLink();
    }
  });
  root.addEventListener('change', (e) => {
    const sel = e.target.closest('select[data-a="linkPick"]');
    if (!sel || !tracker || !sel.value) return;
    const r = tracker.link(sel.getAttribute('data-id'), sel.value);
    linkNote = r.ok ? `Reads joined: ${r.info.names.join(' / ')}, ${handsTxt(r.info.hands)}.` : r.error;
    afterLink();
  });
  // A link changes the reads: advice on the table now was built from the old ones.
  function afterLink() {
    saveDb();
    if (advice && !advice.stale) requestAdvice();
    else render();
  }
  fileIn.addEventListener('change', () => { if (fileIn.files && fileIn.files.length) importLogs([...fileIn.files]); });

  // "Import": hand-log exports (this install's or an older one's) go into the stored log, and the
  // reads are rebuilt by replaying every stored hand that has raw events, as at the table. Removing
  // the extension in Chrome deletes its storage; this brings the reads back from a backup export.
  async function importLogs(files) {
    importing = true;
    importNote = 'Importing…'; render();
    try {
      const got = [];
      for (const f of files) {
        const data = JSON.parse(await f.text());
        const list = Array.isArray(data) ? data : data && Array.isArray(data.history) ? data.history : null;
        if (!list) throw new Error(f.name + ' is not a hand-log export');
        got.push(...list);
      }
      const key = (e) => e.t + ':' + (e.hero || []).join('');
      const stored = await handLog.exportAll(tracker.db);
      const have = new Set(stored.map(key));
      const fresh = [];
      for (const e of got) if (e && e.t != null && !have.has(key(e))) { have.add(key(e)); fresh.push(e); }
      const add = await handLog.addHands(fresh);
      if (!add.ok) throw new Error(add.error || 'storage write failed');
      // Names in logs without account ids map to the ids the reads here already use.
      const known = {};
      for (const [id, r] of Object.entries(tracker.db.players)) if (r && r.name && id.slice(0, 5) !== 'name:') known[r.name] = tracker.canon(id);
      const res = await PatioTracker.rebuildReads(stored.concat(fresh), {
        known, heroAuth: tracker.snap && tracker.snap.heroAuthId, yieldEvery: 10,
        same: tracker.db.same, notSame: tracker.db.notSame, linkLog: tracker.db.linkLog,
        setup: (t) => {
          t.scorer = (show, tally) => PokerEngine.scoreShow(show, tally, ui.tableStyle, t.poolTally());
          t.predictor = PokerEngine.makePredictor(() => ui.tableStyle, () => t.poolTally());
          t.fitVersion = PokerEngine.FIT_VERSION;
        },
        onProgress: (i, n) => { importNote = `Rebuilding reads: ${i} of ${n} hands…`; render(); },
      });
      // A read built from more hands than the log still holds (the log keeps the newest 1,000) stays.
      const handsOf = (r) => { const t = (r && r.tally) || {}; return (t.pfFold || 0) + (t.pfCall || 0) + (t.pfRaise || 0); };
      let kept = 0;
      for (const [id, r] of Object.entries(res.db.players)) {
        const cur = tracker.db.players[id];
        if (cur && handsOf(cur) > handsOf(r) * 1.1 + 2) { kept++; continue; }
        tracker.db.players[id] = r;
      }
      tracker.absorbLinks(res.db);
      await saveDb();
      // The imported hands are in files already: "New hands" starts after them (where they cover
      // every stored hand up to there).
      await moveMark(got).catch(() => null);
      if (ui.showLog) refreshLog();
      importNote = `Imported ${add.added} new hand${add.added === 1 ? '' : 's'} (${got.length - fresh.length} already here). Reads rebuilt from ${res.replayed} hands` +
        (res.skipped ? `; ${res.skipped} without raw events only went into the log` : '') + (kept ? `; ${kept} reads with more history kept as they were` : '') + '.';
    } catch (e) {
      importNote = 'Import failed: ' + ((e && e.message) || e);
    }
    importing = false;
    render();
  }

  // ---------- hand log export ----------
  // "Hand log" opens a short list: the hands since the last export, one session, or every stored
  // hand. Each export used to be every stored hand (612 hands, 20 MB on 5 Nov). The export mark
  // (handlog.js nextMark) is kept on its own key, apart from the reads.
  const MARK_KEY = 'patioSolverLogMark';
  let logView = null; // { times, mark } while the list is open
  let logNote = '';
  let exporting = false;
  const markOf = (m) => (m && typeof m.to === 'number' ? m.to : null);
  async function refreshLog() {
    if (!tracker) return;
    const [times, m] = await Promise.all([handLog.times(tracker.db).catch(() => null), store.get(MARK_KEY)]);
    logView = times ? { times, mark: markOf(m) } : { error: true };
    render();
  }
  function download(hands) {
    const name = PatioHandLog.fileName(hands);
    const url = URL.createObjectURL(new Blob([PatioHandLog.toFile(hands)], { type: 'application/json' }));
    const link = document.createElement('a');
    link.href = url; link.download = name;
    root.appendChild(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    return name;
  }
  // Moves the mark past the hands just exported or imported, as far as they cover every hand.
  // Returns the mark (null: none yet).
  async function moveMark(entries, from) {
    const [times, m] = await Promise.all([handLog.times(tracker.db), store.get(MARK_KEY)]);
    const cur = markOf(m);
    if (!times) return cur;
    const to = PatioHandLog.nextMark(cur, times, entries, Date.now(), from);
    if (to != null && to !== cur) await store.set(MARK_KEY, { to, at: Date.now() });
    return to;
  }
  async function exportLog(what, from, to) {
    if (!tracker || exporting) return;
    exporting = true; logNote = 'Preparing the file…'; render();
    try {
      if (what !== 'logSession') {
        const mark = what === 'logNew' ? markOf(await store.get(MARK_KEY)) : null;
        from = mark != null ? mark : -Infinity;
        to = Infinity;
      }
      let hands = await handLog.exportRange(tracker.db, from, to).catch(() => null);
      let note = '';
      if (!hands) {
        hands = (tracker.db.history || []).filter((e) => e.t > from && e.t <= to);
        note = " The stored hands couldn't be read, so this has only the page's newest 150.";
      }
      if (!hands.length) logNote = 'No hands to export.';
      else {
        const name = download(hands);
        const mark = note ? null : await moveMark(hands, from);
        // The newest hand gets its result when the next hand starts (and shown cards just after
        // it ends), so until then it goes into the next export too.
        const last = hands[hands.length - 1].t;
        const newest = logView && logView.times ? logView.times[logView.times.length - 1] : last;
        if (!note && (what !== 'logSession' || last === newest) && !(mark >= last)) {
          note = ' The last hand will be in the next export too, in case its result or shown cards still come in.';
        }
        logNote = `Saved ${name}: ${handsTxt(hands.length)}.${note}`;
      }
    } catch (e) {
      logNote = 'Export failed: ' + ((e && e.message) || e);
    }
    exporting = false;
    await refreshLog();
  }

  styleSel.addEventListener('change', () => {
    ui.tableStyle = styleSel.value; store.set(UI_KEY, ui);
    if (advice && !advice.stale) requestAdvice();
  });

  // ---------- rendering ----------
  // Linked reads (tracker.js): a friend who came back on a new account id. Same-name matches are
  // asked here and joined only on "Same player"; "Link reads" joins or splits any of them by hand.
  const day = (t) => (t ? new Date(t).toLocaleDateString(undefined, { day: 'numeric', month: 'short' }) : '');
  const handsTxt = (n) => `${Math.round(n)} hand${Math.round(n) === 1 ? '' : 's'}`;
  function readLabel(g) {
    const also = g.names.slice(1, 3);
    return `${g.names[0] || '?'}${also.length ? ' (also ' + also.join(', ') + ')' : ''} · ${handsTxt(g.hands)}${g.last ? ' · seen ' + day(g.last) : ''}`;
  }
  function authOf(name) {
    const h = tracker && tracker.hand;
    const p = h && Object.values(h.players).find((x) => x.name === name);
    return p ? p.auth : null;
  }
  function linkedTxt(auth) {
    const ids = auth ? tracker.groupOf(auth) : [];
    if (ids.length < 2) return '';
    const names = [];
    for (const k of ids) for (const n of tracker.namesOf(k)) if (!names.includes(n)) names.push(n);
    return `Reads from ${ids.length} accounts (${names.join(', ')})`;
  }
  function linkAsksHtml() {
    const asks = tracker && tracker.linkAsks;
    if (!asks) return '';
    const seen = tracker.db.seen || {};
    let html = '';
    for (const a of Object.values(asks)) {
      for (const m of a.matches) {
        const last = Math.max(0, ...m.ids.map((k) => (seen[k] && seen[k].last) || 0));
        html += `<div class="ask"><b>${esc(a.name)}</b> is on an account the reads haven't seen. Same player as the older read ${esc(readLabel(Object.assign({}, m, { last })))}?
          <div class="row"><button class="btn" data-a="linkYes" data-id="${esc(a.id)}" data-to="${esc(m.id)}">Same player</button>
          <button class="btn" data-a="linkNo" data-id="${esc(a.id)}" data-to="${esc(m.id)}">Different players</button></div></div>`;
      }
    }
    return html;
  }
  // Older reads that could be this player, closest name first (the same name, then a shared
  // start like Dew999 / Dew666), then the most recently seen.
  function linkOptions(auth, groups) {
    const mine = tracker.groupOf(auth);
    const nm = (tracker.namesOf(auth)[0] || '').toLowerCase();
    const close = (g) => {
      let best = 0;
      for (const n of g.names.map((x) => x.toLowerCase())) {
        if (n === nm) best = Math.max(best, 3);
        let k = 0;
        while (k < n.length && k < nm.length && n[k] === nm[k]) k++;
        if (k >= 3) best = Math.max(best, 2);
      }
      return best;
    };
    return groups.filter((g) => !g.ids.some((k) => mine.includes(k)) && !tracker.groupsApart(mine, g.ids, true))
      .map((g) => ({ g, c: close(g) })).sort((a, b) => b.c - a.c || b.g.last - a.g.last).map((x) => x.g);
  }
  function linksHtml() {
    if (!tracker) return '';
    const groups = tracker.readGroups();
    const h = tracker.hand, heroId = tracker.heroId();
    let html = '<div><div class="sec">Link reads</div>';
    const at = h ? Object.values(h.players).filter((p) => p.id !== heroId && p.auth) : [];
    if (!at.length) html += '<div class="muted">Players at the table show here once a hand starts.</div>';
    for (const p of at) {
      const opts = linkOptions(p.auth, groups);
      html += `<div class="lk"><span class="nm">${esc(p.name)}</span>` + (opts.length
        ? `<select data-a="linkPick" data-id="${esc(p.auth)}"><option value="">Same player as…</option>${opts.map((g) => `<option value="${esc(g.id)}">${esc(readLabel(g))}</option>`).join('')}</select>`
        : '<span class="muted">no other reads to join</span>') + '</div>';
    }
    const linked = groups.filter((g) => g.ids.length > 1);
    if (linked.length) {
      html += '<div class="sec" style="margin-top:6px">Joined</div>';
      for (const g of linked) {
        html += `<div class="lk"><span>${esc(readLabel(g))}</span>${g.ids.map((k) => `<button class="btn" data-a="unlink" data-id="${esc(k)}" title="This account's hands read on their own again">Split off ${esc(tracker.namesOf(k)[0] || k)} (${handsTxt(handsOfTally(tracker.db.players[k]))})</button>`).join('')}</div>`;
      }
    }
    html += '<div class="muted">Joined reads add both accounts\' hands together; splitting gives each its own hands back. Two accounts that played the same hand can\'t be joined.</div></div>';
    return html;
  }
  const when = (t) => new Date(t).toLocaleString(undefined, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  const hhmm = (t) => new Date(t).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
  function logHtml() {
    let html = '<div><div class="sec">Hand log</div>';
    if (!logView) return html + '<div class="muted">Reading the stored hands…</div></div>';
    if (logView.error) return html + '<div class="status neg">The stored hands couldn\'t be read. Reload the page.</div></div>';
    const { times, mark } = logView;
    const fresh = mark == null ? times.length : times.filter((t) => t > mark).length;
    html += `<div class="muted">${handsTxt(times.length)} stored on this computer (it keeps the newest ${PatioHandLog.KEEP.toLocaleString('en-US')}).` +
      (mark == null ? ' Nothing exported with this version yet, so “New hands” is every stored hand. If you already have those, export just the session you\'re missing; new hands start after it.'
        : ` Exported up to the hand at ${esc(when(mark))}.`) + '</div>';
    html += '<div class="lk">' + (fresh ? `<button class="btn" data-a="logNew">New hands (${fresh})</button>` : '<span class="muted">No new hands since the last export.</span>') +
      `<button class="btn" data-a="logAll">Everything (${times.length})</button></div>`;
    const ss = PatioHandLog.sessions(times).slice(-6).reverse();
    if (ss.length) {
      html += '<div class="sec" style="margin-top:6px">Sessions</div>';
      for (const s of ss) {
        const end = day(s.from) === day(s.to) ? hhmm(s.to) : day(s.to) + ' ' + hhmm(s.to);
        const done = mark != null && s.to <= mark ? ' · exported' : '';
        html += `<div class="lk"><span>${esc(day(s.from) + ' ' + hhmm(s.from) + '–' + end)} · ${handsTxt(s.n)}${done}</span><span style="flex:1"></span>` +
          `<button class="btn" data-a="logSession" data-from="${s.from - 1}" data-to="${s.to}">Export</button></div>`;
      }
    }
    if (logNote) html += `<div class="status${/failed|couldn't/.test(logNote) ? ' neg' : ''}">${esc(logNote)}</div>`;
    return html + '</div>';
  }
  const handsOfTally = (r) => { const t = (r && r.tally) || {}; return (t.pfFold || 0) + (t.pfCall || 0) + (t.pfRaise || 0); };

  function oppReadsHtml(list) {
    if (!list.length) return '';
    return `<div><div class="sec">Reads</div>${list.map((o) => `
      <div class="opp"><span class="nm">${esc(o.name)}</span><span class="ty">${esc(o.type)}</span>
        <div class="muted">${Math.round(o.hands)} hand${Math.round(o.hands) === 1 ? '' : 's'} · VPIP ${pct(o.vpip)} · PFR ${pct(o.pfr)} · folds to bets ${pct(o.ftb)}${o.likely ? ' · likely ' + esc(o.likely) : ''}</div>
        ${o.summary ? `<div class="muted">${esc(o.summary)}</div>` : ''}
        ${o.linked ? `<div class="muted">${esc(o.linked)}</div>` : ''}
        ${o.bluffChance != null ? `<div class="tip">Bluffing here about ${pct(o.bluffChance)} of the time</div>` : ''}
        ${o.tip ? `<div class="tip">${esc(o.tip)}</div>` : ''}</div>`).join('')}</div>`;
  }

  function liveReads() {
    if (!tracker || !tracker.hand || !window.PokerEngine) return [];
    const heroId = tracker.heroId();
    const out = [];
    for (const p of Object.values(tracker.hand.players)) {
      if (p.id === heroId) continue;
      const tally = Object.assign(PatioTracker.blankTally(), tracker.readTally(p.auth) || {});
      const st = PokerEngine.computeStats(tally, ui.tableStyle, tracker.poolTally());
      const ty = PokerEngine.classifyPlayer(st);
      out.push({ name: p.name + (p.folded ? ' (folded)' : ''), type: ty.label, tip: '', hands: st.hands, vpip: st.raw.vpip, pfr: st.raw.pfr, ftb: st.raw.foldToBet, summary: PokerEngine.readSummary(st), linked: linkedTxt(p.auth) });
    }
    return out;
  }

  const HOOK_MSG = {
    nosocket: 'Can’t find the game’s connection, so there is no advice. Poker Patio may have changed: Patio Solver needs an update.',
    silent: 'The table is moving but no game events arrive, so there is no advice. Poker Patio may have changed: Patio Solver needs an update.',
  };
  function render() {
    styleSel.value = ui.tableStyle;
    dot.className = 'dot' + (blocked ? '' : hookProblem ? ' bad' : advice && !advice.stale || thinking ? ' turn' : tracker && tracker.snap ? ' live' : '');
    root.querySelector('[data-a="collapse"]').textContent = ui.collapsed ? '+' : '–';
    body.style.display = ui.collapsed ? 'none' : '';
    foot.style.display = ui.collapsed || blocked ? 'none' : '';
    if (ui.collapsed) {
      if (advice && !advice.stale) {
        const r = advice.result;
        root.querySelector('.hd b').textContent = actionText(r.best, advice.ctx.heroStageBet, r.toCall);
      } else root.querySelector('.hd b').textContent = 'Patio Solver';
      return;
    }
    root.querySelector('.hd b').textContent = 'Patio Solver';
    if (blocked) { body.innerHTML = `<div class="status">${esc(status)}</div>`; return; }

    const h = tracker && tracker.hand;
    let html = '';
    if (hookProblem && HOOK_MSG[hookProblem]) html += `<div class="status neg">${esc(HOOK_MSG[hookProblem])}</div>`;
    const heroCards = h ? h.heroUids.map((u) => h.heroCards[u]).filter(Boolean) : [];
    if (heroCards.length || (h && h.board.length)) {
      html += `<div class="hand">${heroCards.map(cardHtml).join('')}${h.board.length ? '<span class="muted">&nbsp;board</span>' + h.board.map(cardHtml).join('') : ''}</div>`;
    }

    if (thinking && !(advice && !advice.stale)) {
      html += `<div class="rec"><div class="sub"><span class="spin"></span>Working out your best move…</div></div>`;
    }
    if (advice) {
      const r = advice.result, c = advice.ctx;
      const best = r.best;
      const evLine = best.kind === 'fold' ? 'Every other option loses chips' : (best.ev >= 0 ? '+' : '−') + money(Math.abs(best.ev)) + ' expected';
      html += `<div class="rec ${tone(best)} ${advice.stale ? 'stale' : ''}">
        <div class="act">${actionHtml(best, c.heroStageBet, r.toCall)}${r.close ? '<span class="badge">close</span>' : ''}</div>
        <div class="sub">${best.sizeLabel && best.sizeLabel !== 'raise' ? esc(best.sizeLabel) + ' · ' : ''}${evLine}${advice.stale ? ' · last turn' : ''}</div>
        ${r.mix ? `<div class="sub">Close spot, so mix it up: ${r.mix.map((m) => esc(m.label) + ' ' + pct(m.freq)).join(' · ')}. This time: ${esc(best.label)}.</div>` : ''}
        ${advice.stale && sizing.note ? `<div class="sub neg">${esc(sizing.note)}</div>` : ''}
      </div>`;
      const kv = [];
      if (r.hero) kv.push(['Your hand', esc(r.hero.made + (r.hero.draws && r.hero.draws.length ? ' + ' + r.hero.draws.map((d) => d.name.toLowerCase()).join(', ') : '') + (r.street === 0 && r.hero.topPercent != null ? ` (top ${Math.max(1, Math.round(r.hero.topPercent))}%)` : ''))]);
      if (r.equity) kv.push(['Equity vs their ranges', pct(r.equity.share)]);
      if (r.toCall > 0) kv.push(['Needed to call', pct(r.potOdds)]);
      kv.push(['Pot', money(r.pot)]);
      kv.push(['Position', r.inPosition ? 'In position (you act last)' : 'Out of position']);
      if (r.lookahead) kv.push(['Plans ahead', r.street === 3 ? 'Turn and river' : 'River']);
      if (r.solver) kv.push([{ preflop: 'Preflop solve', turn: 'Turn + river solve', river: 'River solve' }[r.solver.kind] || 'Solve', r.solver.field ? 'Your range vs the field' : 'Your range vs theirs']);
      if (r.blueprint && r.blueprint.actions) {
        const top = r.blueprint.actions.slice().sort((a, b) => b.p - a.p).filter((a) => a.p >= 0.1).map((a) => ({ fold: 'Fold', check: 'Check', call: 'Call', bet: 'Bet', raise: 'Raise', allin: 'All-in' }[a.kind] + ' ' + pct(a.p)));
        kv.push(['Blueprint (self-play)', esc(top.join(' · ') || '—')]);
      }
      if (advice.ms != null) kv.push(['Thinking', `${(advice.ms / 1000).toFixed(1)}s on ${advice.workers || 1} core${advice.workers > 1 ? 's' : ''}`]);
      if (best.foldPct > 0.02 && (best.kind === 'bet' || best.kind === 'raise' || best.kind === 'allin')) kv.push(['They fold to this', pct(best.foldPct)]);
      html += `<div class="kv">${kv.map(([k, v]) => `<span>${k}</span><span>${v}</span>`).join('')}</div>`;

      html += `<div><div class="sec" style="cursor:pointer" data-a="toggleOpts">All options ${ui.showOptions ? '▾' : '▸'}</div>`;
      if (ui.showOptions) {
        html += `<table>${r.ranked.map((s) => `<tr class="${s === r.ranked.find((x) => x.kind === best.kind && x.amount === best.amount) ? 'best' : ''}">
          <td>${optionHtml(s, c.heroStageBet, r.toCall)}</td>
          <td class="${s.ev < 0 ? 'neg' : s.ev > 0 ? 'pos' : ''}">${s.ev >= 0 ? '+' : '−'}${money(Math.abs(s.ev))}</td></tr>`).join('')}</table>`;
      }
      html += `</div>`;
      html += linkAsksHtml();
      html += oppReadsHtml(r.opponents.map((o) => ({
        name: o.name, type: o.type.label, tip: o.type.key !== 'unknown' ? o.type.tip : '', hands: o.stats.hands,
        vpip: o.stats.vpip, pfr: o.stats.pfr, ftb: o.stats.foldToBet, likely: o.topClasses.slice(0, 5).join(' '),
        summary: o.summary, bluffChance: o.bluffChance, linked: linkedTxt(authOf(o.name)),
      })));
    } else {
      if (!thinking) html += `<div class="status">${esc(status)}</div>`;
      html += linkAsksHtml();
      html += oppReadsHtml(liveReads());
    }
    if (linkNote) html += `<div class="status">${esc(linkNote)}</div>`;
    if (ui.showLinks) html += linksHtml();
    if (ui.showLog) html += logHtml();
    const n = tracker ? tracker.readGroups().length : 0;
    html += `<div class="muted">Tracking ${n} player${n === 1 ? '' : 's'}. Reads sharpen as hands pile up.</div>`;
    if (sizing.small) html += `<div class="muted">Bets this session under ${Math.round(SMALL_SIZE * 100)}% of the advised size: ${sizing.small} of ${sizing.n}.</div>`;
    if (saveError) html += `<div class="status neg">Couldn't save reads and the hand log: ${esc(saveError)}</div>`;
    if (importNote) html += `<div class="status${/failed/.test(importNote) ? ' neg' : ''}">${esc(importNote)}</div>`;
    body.innerHTML = html;
  }

  // ---------- solver ----------
  // The computer shows only the full solve (every spare core). The quick read on one core that
  // used to show first was dropped (Marwin, 1 Nov): if you act before the full solve is back,
  // nothing was shown and nothing is logged for that decision.
  function note(a) {
    if (!a || a.noted) return;
    a.noted = true;
    const r = a.result, c = a.ctx;
    tracker.noteAdvice(actionText(r.best, c.heroStageBet, r.toCall), r.best.ev || 0, r, function (sc) { return actionText(sc, c.heroStageBet, r.toCall); });
  }
  async function requestAdvice(timeLeftMs) {
    const built = tracker.solverInput(ui.tableStyle);
    if (built.error) { status = built.error; render(); return; }
    const id = ++reqId;
    thinking = true;
    sizing.note = null;
    if (advice) advice.stale = true;
    render();
    const input = timeLeftMs > 0 ? Object.assign({}, built.input, { timeLeftMs }) : built.input;
    const res = await analyze(input);
    if (id !== reqId) return;
    thinking = false;
    if (!res || !res.ok) { status = 'Solver error: ' + (res && res.error); advice = null; render(); return; }
    advice = { result: res.result, ctx: built, stale: false, ms: res.ms, workers: res.workers };
    note(advice);
    render();
  }

  // ---------- wiring ----------
  async function start() {
    const saved = await store.get(UI_KEY);
    if (saved) ui = Object.assign(ui, saved);
    const loaded = await handLog.load(PatioTracker.MAX_HISTORY, PatioTracker.RAW_KEEP);
    if (loaded.error) noteSaved({ ok: false, error: loaded.error });
    // A fresh install (no reads stored): the reads come back from the site's copy, if there is one.
    const copy = await backup.load().catch(() => null);
    if (!loaded.error && copy && !Object.keys(loaded.db.players || {}).length && Object.keys(copy.reads.players).length) {
      const history = loaded.db.history && loaded.db.history.length ? loaded.db.history : copy.history;
      loaded.db = Object.assign({}, copy.reads, { history });
      const np = Object.keys(copy.reads.players).length;
      importNote = `Reads brought back from this site's backup (${np} player${np === 1 ? '' : 's'}, ${history.length} hand${history.length === 1 ? '' : 's'} of log${copy.savedAt ? ', saved ' + new Date(copy.savedAt).toLocaleString() : ''}).`;
      restored = true;
    }
    tracker = new PatioTracker(loaded.db);
    // Reads saved before v1.8.8 don't know who played together: learned from the stored hands.
    tracker.learnSeats(loaded.db.history || []);
    tracker.scorer = (show, tally) => PokerEngine.scoreShow(show, tally, ui.tableStyle, tracker.poolTally());
    tracker.predictor = PokerEngine.makePredictor(() => ui.tableStyle, () => tracker.poolTally());
    tracker.fitVersion = PokerEngine.FIT_VERSION;
    if (restored) saveDb();
    if (ui.showLog) refreshLog();
    // Shows saved before v1.8.9 don't say whether hero was in the pot, which the learned hero-pot tilt needs: they
    // are filled in once from every stored hand, so the tilt starts from the table's history instead of from 0.
    if (!tracker.db.hpTagged) {
      handLog.exportAll(tracker.db).catch(() => tracker.db.history || []).then((hands) => {
        tracker.tagHeroPot(hands);
        tracker.db.hpTagged = 1;
        saveDb();
      });
    }
    // Shown all-in re-raises from hands stored before v1.8.27 don't count in the per-player deep-shove read
    // (tally.jamShows): filled in once from every stored hand.
    if (!tracker.db.jamTagged) {
      handLog.exportAll(tracker.db).catch(() => tracker.db.history || []).then((hands) => {
        tracker.tagJamShows(hands);
        tracker.db.jamTagged = 1;
        saveDb();
      });
    }
    tracker.on((type) => {
      if (type === 'save') saveDb();
      if (type === 'hand') { advice = null; thinking = false; reqId++; sizing.note = null; status = 'New hand. Waiting for your turn…'; render(); }
      if (type === 'turn') { /* handled below with payload */ }
      if (type === 'handEnd') { if (advice) advice.stale = true; thinking = false; reqId++; status = 'Hand over. Waiting for the next one…'; render(); }
      if (type === 'handEnd' && ui.showLog && local.keys) refreshLog();
      if (type === 'action') checkSize();
      if (type === 'action' || type === 'street' || type === 'cards' || type === 'linkAsk') render();
    });
    tracker.on((type, p) => {
      if (type === 'turn' && p.isHero) requestAdvice(p.timeLeftMs);
      else if (type === 'turn' && advice && !advice.stale) { advice.stale = true; render(); }
      if (type === 'heroDone') { reqId++; thinking = false; if (advice) advice.stale = true; render(); }
    });

    window.addEventListener('message', (e) => {
      if (e.source !== window || !e.data || e.data.source !== 'patio-solver-hook') return;
      const { ev, data, snap } = e.data;
      // Private lobbies only. A table whose type isn't known yet (page still loading) is off too.
      if (!snap || snap.tableType !== 'private') {
        blocked = true;
        status = snap && snap.tableType
          ? 'Patio Solver only runs in private lobbies you play with friends. It stays off at public tables.'
          : 'Waiting to see what kind of table this is…';
        render();
        return;
      }
      blocked = false;
      if (ev === 'hook:health') {
        hookProblem = (data && data.problem) || null;
        render();
        return;
      }
      if (ev === 'hook:attached' || ev === 'hook:snapshot') {
        tracker.snap = snap;
        if (ev === 'hook:attached') hookProblem = null;
        // An answer from a hook that has no socket yet (older hooks send no data and count as attached).
        if (ev === 'hook:snapshot' && data && data.problem !== undefined) hookProblem = data.problem || null;
        if (!tracker.hand) status = ev === 'hook:snapshot' && data && data.attached === false ? 'Looking for the game’s connection…' : 'Connected. Advice starts with the next hand.';
        render();
        return;
      }
      tracker.handle(ev, data, snap);
    });

    (document.body || document.documentElement).appendChild(host);
    place();
    window.addEventListener('resize', place);
    render();
    window.postMessage({ source: 'patio-solver-overlay', type: 'snapshot' }, location.origin);
  }

  start();
})();
